﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Comunalka.Classes;
using Excel = Microsoft.Office.Interop.Excel;
using System.Reflection;
using System.IO;
using Newtonsoft.Json;

namespace Comunalka.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageComun.xaml
    /// </summary>
    public partial class PageComun : Page
    {
        public PageComun()
        {
            InitializeComponent();
            DGridUsers.ItemsSource = Comunal_paymentsEntities.GetContext().Building.ToList();

            CmbFiltrAdress.ItemsSource = Comunal_paymentsEntities.GetContext().Owner.ToList();
            CmbFiltrAdress.SelectedValuePath = "idOwner";
            CmbFiltrAdress.DisplayMemberPath = "FIO";

        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageEdit(null));
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            var usersForRemoving = DGridUsers.SelectedItems.Cast<Building>().ToList();
            if (MessageBox.Show($"Удалить {usersForRemoving.Count()} пользователей?",
                "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)

                try
                {
                    Comunal_paymentsEntities.GetContext().Building.RemoveRange(usersForRemoving);
                    Comunal_paymentsEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены");
                    DGridUsers.ItemsSource = Comunal_paymentsEntities.GetContext().Building.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageEdit((sender as Button).DataContext as Building));
        }

        private void TxtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            DGridUsers.ItemsSource = Comunal_paymentsEntities.GetContext().Building.Where(x => x.Residing.FIO.ToLower().Contains(TxtSearch.Text.ToLower())).ToList();
        }

        private void BtnResetAll_Click(object sender, RoutedEventArgs e)
        {
            DGridUsers.ItemsSource = Comunal_paymentsEntities.GetContext().Building.ToList();
        }

        private void CmbFiltrAdress_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int id = Convert.ToInt32(CmbFiltrAdress.SelectedValue);
            DGridUsers.ItemsSource = Comunal_paymentsEntities.GetContext().Building.Where(x => x.IDOwner == id).ToList();
        }

        private void RbDown_Checked(object sender, RoutedEventArgs e)
        {
            DGridUsers.ItemsSource = Comunal_paymentsEntities.GetContext().Building.OrderByDescending(x => x.Price).ToList();
        }

        private void RbUp_Checked(object sender, RoutedEventArgs e)
        {
            DGridUsers.ItemsSource = Comunal_paymentsEntities.GetContext().Building.OrderBy(x => x.Price).ToList();
        }

        private void BtnToExcel_Click(object sender, RoutedEventArgs e)
        {
            var app = new Excel.Application();
            Excel.Workbook wb = app.Workbooks.Add();
            Excel.Worksheet worksheet = app.Worksheets.Item[1];
            int indexrows = 1;
            worksheet.Cells[1][indexrows] = "Предмет";
            var printItems = Comunal_paymentsEntities.GetContext().Building.ToList();
            foreach (var item in printItems)
            {
                worksheet.Cells[1][indexrows + 1] = item.Adress;
                indexrows++;
            }
            app.Visible = true;
        }

        private void BtnAddOwner_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageEditOwner((sender as Button).DataContext as Owner));
        }

        private void BtnAddResiding_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageEditResiding((sender as Button).DataContext as Residing));
        }

        private void JsonSave_Click(object sender, RoutedEventArgs e)
        {
            File.WriteAllText("input.json", string.Empty);
            foreach(var nt in Comunal_paymentsEntities.GetContext().Residing)
            {
                Residing residing = new Residing()
                {
                    FIO = nt.FIO,
                    Age = nt.Age
                };
                File.AppendAllText("input.json", JsonConvert.SerializeObject(residing));
            }
        }

        private void JsonSearch_Click(object sender, RoutedEventArgs e)
        {
            List<Residing> ntttt = new List<Residing>();
            JsonTextReader reader = new JsonTextReader(new StreamReader("input.json"));
            reader.SupportMultipleContent = true;
            while (reader.Read())
            {
                JsonSerializer serializer = new JsonSerializer();
                Residing temp_point = serializer.Deserialize<Residing>(reader);
                if (temp_point.FIO.Contains(TxtSearchJson.Text))
                    ntttt.Add(temp_point);
            }
            string s = "";
            foreach (Residing nt in ntttt)
            {
                s += nt.FIO + " " + nt.Age + "\n";
            }
            MessageBox.Show(s);
        }
    }
}
