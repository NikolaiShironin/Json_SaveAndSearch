﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Comunalka.Classes;

namespace Comunalka.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageFunction.xaml
    /// </summary>
    public partial class PageFunction : Page
    {
        public PageFunction()
        {
            InitializeComponent();
            DGridUsers.ItemsSource = Comunal_paymentsEntities.GetContext().Building.ToList();

            
        }

        private void BtnCount_Click(object sender, RoutedEventArgs e)
        {
            int doo = int.Parse(TxtDo.Text);
            DGridUsers.ItemsSource = Comunal_paymentsEntities.GetContext().Building.Where(x => x.Price <=doo).ToList();
        }

        private void BtnCountot_Click(object sender, RoutedEventArgs e)
        {
            int ot = int.Parse(TxtOt.Text);
            DGridUsers.ItemsSource = Comunal_paymentsEntities.GetContext().Building.Where(x => x.Price >= ot).ToList();
        }

        private void BtnMore3_Click(object sender, RoutedEventArgs e)
        {
            DGridUsers.ItemsSource = Comunal_paymentsEntities.GetContext().Building.Where(x => x.AmountResiding > 3).ToList();
        }
    }
}
